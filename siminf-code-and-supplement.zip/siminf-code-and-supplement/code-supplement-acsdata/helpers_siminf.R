# Functions for Standardisation variables

standardize <- function(x) {
  xs <- apply(x,2, function(x) if(var(x)!=0) {(x-mean(x))/sqrt(var(x))} else {x-mean(x)})
  return(xs)
}

normalize <- function(x) {
  xs <- apply(x,2, function(x) (x-mean(x)))
  return(xs)
}

# function for transforming educd (categorial) to years of schooling (yearssch), according to Table SI and SII in Angrist et al. (2006)
tab <- function(int, school) {
  yearssch <- NA
  if(int <= 18 && int >=12) yearssch <- 8    # 5th, 6th, 7th, or 8th grade (note: coding in data set differs from coding in original survey/IPUMS website)
  if(int == 19) yearssch <- 9 
  if(int == 20) yearssch <- 10 
  if(int == 21) yearssch <- 11
  if(int == 22) yearssch <- 11
  if(int == 23) yearssch <- 11  # Although "Grade 12" is coded as 11 years of schooling, this coding is in line with Angrist and Krueger (1999)
  if(int == 24) yearssch <- 12
  if(int == 25) yearssch <- 12
  if(int == 26) yearssch <- 12
  if(int == 27) yearssch <- 13
    if(int == 31) yearssch <- 14 
  if(int == 32) yearssch <- 14 # not in table
    if(int == 33) yearssch <- 15 # not in table
    #if(int == 36 && school== 3) yearssch <- 16 # not attending school
  #if(int == 36 && school== 4) yearssch <- 17 # now enrolled
    if(int == 36 && school== 2) yearssch <- 16 # not attending school
  if(int == 36 && school== 3) yearssch <- 17 # now enrolled
    if(int == 41) yearssch <- 18
  if(int == 42) yearssch <- 19
  if(int == 43) yearssch <- 20
    # college degrees (cf Table SI)
  if(int == 28) yearssch <- 13
  if(int == 29) yearssch <- 13
  if(int == 30) yearssch <- 14
  if(int == 34) yearssch <- 15
  if(int == 35) yearssch <- 16
  if(int == 37) yearssch <- 17 # category is "5+ (not 5) years of college2", not in table
  if(int == 38) yearssch <- 18
  if(int == 39) yearssch <- 19
  if(int == 40) yearssch <- 20
    return(yearssch)
}

# calculating of weeks worked (average over categories) 

#### Fct. commented out as we focus on full time employees first! 
# (no need to adjust for weeks worked)

# weeks <- function(int) {
#  we <- NA
#  if (int==1) we <- 0
#  if (int==2) we <- 10
#  if (int==3) we <- 20
#  if (int==4) we <- 35
#  if (int==5) we <- 45
#  if (int==6) we <- 49
#  if (int==7) we <- 52
#  return(we)
#}

#dropall <- function(x){
#  isFac = NULL
#  for (i in 1:dim(x)[2]){isFac[i] = is.factor(x[ , i])}
#  
#  for (i in 1:length(isFac)){
#    x[, i] = x[, i][ , drop = TRUE]
#  }
#  return(x)
#}


# function for coding Industry (variable ind1990)   ## Function needs to be run before further data size reduction as
                                                    ##  it cannot handle empty cells (e.g. NAs after exclusion of subgroups)
IND <- function(x) {
  n <- length(x)
  convert <- vector("numeric", length=n)
  for (i in 1:n) {
    value <- as.numeric(x[i])
    if (value==1) convert[i] <- 0                 # NAs
    if (value>=2 & value<=8) convert[i] <- 1      # Agriculture 
    if (value>=9 & value<=12) convert[i] <- 2     # Mining
    if (value==13) convert[i] <- 3                # Construction
    if (value>=14 & value<=95) convert[i] <- 4    # Manufacturing
    if (value>=96 & value<=114) convert[i] <- 5   # Transportation, communications, and other public utilities
    if (value>=115 & value<=134) convert[i] <- 6  # Wholesale trade
    if (value>=135 & value<=170) convert[i] <- 7  # Retail trade
    if (value>=171 & value<=176) convert[i] <- 8  # Finance, insurance and real estate
    if (value>=177 & value<=187) convert[i] <- 9  # Business and repair services
    if (value>=188 & value<=197) convert[i] <- 10 # Personal services
    if (value>=198 & value<=201) convert[i] <- 11 # Entertrainment and recreation services
    if (value>=202 & value<=229) convert[i] <- 12 # Professional and related services
    if (value>=230 & value<=237) convert[i] <- 13 # Public Administration
    if (value>=238 & value<=244) convert[i] <- 14 # Active duty military
    if (value>=245 & value<=247) convert[i] <- 15 # Experienced unemployed not classified by industry / did not respond (0)
  }
  
  convert <- as.factor(convert)
  levels(convert) <- c("not applicable", "AGRI", "MINING", "CONSTR", "MANUF", "TRANS", "WHOLESALE", "RETAIL", "FINANCE", "BUISREPSERV", "PERSON", "ENTER", "PROFE", "ADMIN", "MILIT", "NOTRESP")
  return(convert)
}


# function for coding occupation 
##  it cannot handle empty cells (e.g. NAs after exclusion of subgroups)

OCC <- function(x) {
  n <- length(x)
  convert <- vector("numeric", length=n)
  for (i in 1:n) {
    value2 <- as.numeric(x[i])
    if (value2>=1 & value2<=22) convert[i] <- 0    # Management, Business, Science, Arts.
    if (value2>=23 & value2<=34) convert[i] <- 1    # Business Operations Specialists 
    if (value2>=35 & value2<=46) convert[i] <- 2    # Financial Specialist
    if (value2>=47 & value2<=56) convert[i] <- 3    # Computer and Mathematical
    if (value2>=57 & value2<=71) convert[i] <- 4    # Architecture and Engineering
    if (value2>=72 & value2<=73) convert[i] <- 5    # Technicians
    if (value2>=74 & value2<=93) convert[i] <- 6    # Life, Physical, and Social Science
    if (value2>=94 & value2<=99) convert[i] <- 7    # Community ans Social Services
    if (value2>=100 & value2<=102) convert[i] <- 8  # Legal
    if (value2>=103 & value2<=113) convert[i] <- 9  # Education, Training, and Library
    if (value2>=114 & value2<=129) convert[i] <- 10 # Arts, Design, Entertainment, Sports, and Media
    if (value2>=130 & value2<=158) convert[i] <- 11 # Healthcare Practitioners and Technical
    if (value2>=159 & value2<=164) convert[i] <- 12 # Healthcare Support
    if (value2>=165 & value2<=177) convert[i] <- 13 # Protective Services
    if (value2>=178 & value2<=188) convert[i] <- 14 # Food Preparation and Serving
    if (value2>=189 & value2<=194) convert[i] <- 15 # Building and Grounds Cleaning and Maintenance
    if (value2>=195 & value2<=212) convert[i] <- 16 # Personal Care and Service
    if (value2>=213 & value2<=229) convert[i] <- 17 # Sales and Related
    if (value2>=230 & value2<=279) convert[i] <- 18 # Office and Administrative Support
    if (value2>=280 & value2<=286) convert[i] <- 19 # Farming, Fishing, and Forestry
    if (value2>=287 & value2<=315) convert[i] <- 20 # Construction
    if (value2>=316 & value2<=320) convert[i] <- 21 # Extraction
    if (value2>=321 & value2<=354) convert[i] <- 22 # Installation, Maintenance, and Repair
    if (value2>=355 & value2<=425) convert[i] <- 23 # Production
    if (value2>=426 & value2<=454) convert[i] <- 24 # Transportation and Material Moving
    if (value2>=455 & value2<=458) convert[i] <- 25 # Military Specific
    if (value2==459) convert[i] <- 26              # Unemployed or never worked
  }
  
  convert <- as.factor(convert)
  
  levels(convert) <- c("Managmnt, Bus/Science/Art", "Bus Operat Spec", "Financ Spec",
                       "Comput/Math", "Archit/Engin", "Technic",
                       "Life/Physical/Soc Sci.", "Comm/Soc Serv", "Legal", 
                       "Educ/Training/Libr", "Arts/Design/Entert/Sports/Media", 
                       "Healthc Pract/Technic", "Healthc Supp", "Protect Serv", 
                       "Food Prepar/Serving", "Build/Grounds Clean/Mainten", 
                       "Pers Care/Serv", "Sales", "Office/Administr Supp",
                       "Farm/Fish/Forestry", "Constr", "Extract", "Install/Mainten/Rep",
                       "Prod", "Transp", "Milit Specific", "Unempl/never worked")

  return(convert)
}



HRSWKD <- function(x) {
  n <- length(x)
  convert <- vector("numeric", length=n)
  for (i in 1:n) {
    value <- as.numeric(x[i])
    if (value==0) convert[i] <- 0                 # NAs
    if (value>=30 & value<=39) convert[i] <- 1      # less than 40 hrs
    if (value>=40 & value<=49) convert[i] <- 2     # 40-49
    if (value>=50 & value<= 59) convert[i] <- 3    # 50-59
    if (value>=60 & value<=69) convert[i] <- 4    # 60-69
    if (value>=70) convert[i] <- 5   # 70+
     }
  
  convert <- as.factor(convert)
  levels(convert) <- c("NA", "Lessthan40", "40to49", "50to59", "60to69", "70plus")
  return(convert)
}


checkvar_factor = function(x, tol = 10e-4){
  checkmate::checkFactor(x)
  x2 <- x
  
  for (j in 1:length(levels(x))){
    lev <- levels(x)[j]
    y <- as.numeric(x == lev)
    
    
    if (var(y) < tol){
      x2[x2 == lev] <- NA
    }
    
  }
  return(x2)
}
