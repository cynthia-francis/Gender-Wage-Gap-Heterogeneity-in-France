rm(list=ls())
library(foreign)

# Enter the directory where all files are saved here:
path = "yourdirectory"

setwd(paste0(path))

# Run file with help functions
source(paste0(path, "/helpers_siminf.R"))

# Use IPUMS-Data Excerpt (ACS data 2016) - in our example, the excerpt was names usa_00013.dta
data <- read.dta(paste0(path, "/usa_00013.dta"))

dim(data)
(n <- dim(data)[1])

########################################################################
############ I. Convert and Construct Variables ########################
########################################################################

#data conversion and check for NA-values (missing obs)

# Gender
data$sex <- as.factor(data$sex =="Female")

## Age
levels(data$age)
# Necessary to transform variable (-1) so that levels coincide (otherwise "0" is 1... )
data$age <- as.integer(data$age) - 1  

## Education
data$education <- data$educd
levels(data$educd)

# Education as integer
data$educd <- as.integer(data$educd)
levels(data$school)

## Race, merge Japanese and other Asian/Pacific Islander to one group
levels(data$race)[5] <- levels(data$race)[6] # Japanese to Other Asian or Pacific Islander

## Hispanic (merge categories to one)
## Note: In the ACS Hispanic is treated as a characteristic distinct from race, see for instance https://usa.ipums.org/usa-action/variables/RACOTHER#questionnaire_text_section
data$hispanic <- as.factor(data$hispan == "Mexican" | data$hispan == "Puerto Rican" | data$hispan == "Cuban" | data$hispan == "Other")

## School Attendance
data$school <- as.integer(data$school)

## Weeks Worked
levels(data$wkswork2)
data$wkswork2 <- as.integer(data$wkswork2) # NA's coded as 1

## Hours worked, convert to a numeric variable
levels(data$uhrswork)
data$hoursworked <- as.numeric(data$uhrswork)-1 # NA's coded as 0

##### generate categorical hoursworked variable
data$hw <- HRSWKD(data$hoursworked)

## Field of Degree (Bachelor)
cbind(table(data$degfield))     # Note: coding coincides with original coding (IPUMS)
data$degfield <- as.factor(data$degfield)

## Industry
##  Recode industry variable
data$ind1990c <- IND(data$ind1990) # smaller industry classification

## Occupation
# Recode Occupation variable
data$occ2010c <- OCC(data$occ2010) # smaller occupation classification 

## Family Size
data$famsize <- as.integer(data$famsize)

### dummy whether an own child under age 18 is living in the same household

# yngch: age of youngest own children (if any) living in the same household. No own children in the same household coded as 99.
data$yngch <- as.numeric(data$yngch)-1

data$dchlt19 <- as.integer(data$yngch <= 18)

### dummy variables for metropolitan statistical area
table(data$metro)

data$msa <- as.integer(data$metro == "In metro area, central / principal city" | data$metro == "In metro area, outside central / principal city"| data$metro == "Central / Principal city status unknown")

#########################################################################
######## II. Subsetting the Data (excluding observations) ###############
#########################################################################

## Data selection

## Only include observations with at least 12 years of schooling who do not attend school at the time of the interview
data <- subset(data, educd >= 12) # more than 5 years of eduction
data <- subset(data, school==2) # 2 - No, not in school, 3 - Yes, in school

## Create Variable Years of Schooling
n <- dim(data)[1]
yos <- rep(NA, dim(data)[1])
for (i in 1:n) {
  yos[i] <- tab(data$educd[i], data$school[i])
}
data$yos <- yos
rm(yos)

## Focus on major race groups, exclude NAs
data <- subset(data, race=="White" | race=="Black/African American/Negro" | race=="Chinese" | race=="Other Asian or Pacific Islander") #selection for race

## Include employed individuals only (exclude NAs, unemployed and "not in labor force")
data <- subset(data, empstat=="Employed") 

## Exclude NAs w.r.t. veteran status
data <- subset(data, vetstat=="Veteran" | vetstat=="Not a veteran") # only veteran and non-veteran

## English language skills (if individuals report that they speak another language at home)
data <- subset(data, speakeng=="Does not speak English" | speakeng=="Yes, speaks English..." | speakeng=="Yes, speaks only English" | 
                 speakeng=="Yes, speaks very well" | speakeng=="Yes, speaks well" | speakeng=="Yes, but not well" )


## Exclude students 
data <- subset(data, schltype=="Not enrolled")  

## Exclude observations with industry = "not applicable" and non-respondents
data<-subset(data, ind1990c!=" NOTRESP" & ind1990c!="not applicable")

## Exlude observations with "unemployed or never worked" as occupation
data <- subset(data, occ2010c!="Unemployed or never worked")

data <- subset(data, metro != "Not identifiable")

## Only include persons working full year (50-52 weeks)
 # Watch out, NAs are coded as 1!
data <- subset(data, wkswork2==7) 

# BLS/CPS definition: include only individuals with 35+ hrs of work per week
data <- subset(data, hoursworked>=35)

# Exclude NAs w.r.t. income
data <- subset(data, incwage!=999999) 

# discard incomes below the federale minimum wage level 7.25 (introduced in 2009 and not adjusted ever since)
# Note that item in questionnaire includes tip as source of income and 7.25 is also the minimum wage for
# workers for whom tip-regulations apply

# Minimum wage for a full-time employee (50+ weeks, 35+ hours of work)
minwage <- 50*35*7.25

# data <- subset(data, incwage >= quantile(data$incwage, probs = 0.025) & incwage <= quantile(data$incwage, probs = 0.975))
data <- subset(data, incwage >= minwage )

## Compute weekly earnings for full time workers (50)
data$wwage <- data$incwage/52 # weekly wage
data$lwwage <- log(data$wwage) # log weekly wage

# Only include individuals aged 25 to 65 (in line with the literature)
data <- subset(data,  age >= 25 & age <=65)

# calculating experience
data$exp <- data$age - 6 - data$yos
data$exp2 <- data$exp^2
data <- subset(data, exp>=0 & exp<=60)

# Scale experience and experience2 down so that sd is comparable to other continuous regressors (i.e. yos)
data$exp <- data$exp 
data$exp2 <- data$exp2/50


########################################################
######## Drop Levels and Relevel #######################
#########################################################

# Drop unused categories of race etc.
data$race <- droplevels(data$race)
data$vetstat <- droplevels(data$vetstat)
data$speakeng <- droplevels(data$speakeng)
data$ind1990c <- droplevels(data$ind1990c)
data$occ2010c <- droplevels(data$occ2010c)
data$degfield <- droplevels(data$degfield)
data$schltype <- droplevels(data$schltype)
data$region <- droplevels(data$region)
data$classwkrd <- droplevels(data$classwkrd)
data$hw <- droplevels(data$hw)

# relevel
data$speakeng <- relevel(data$speakeng, "Yes, speaks only English")
data$ind1990c <- relevel(data$ind1990c, "WHOLESALE")
levels(data$degfield) <- c("Bachelor",	"Agri" ,"Envir/Nat Res", "Archit", "Area/Ethnic/Civiliz Stud", "Comm",
                           "Comm Tech", "Comp/Inform Sci", "Cosmet Serv/Culin Arts", "Educ Admin/Teach",
                           "Engin", "Engin Techn", "Ling/Foreign Lang", "Fam/Consum Sci", "Law", "English/Lit/Compos",
                           "Lib Arts/Hum", "Lib Sci", "Bio/Life Sci", "Math/Stats", "Milit Techn",
                           "Inter-/Multi-Disc Stud (gen)", "Phys Fit/Parks/Recr/Leis", "Philos/Rel Stud",
                           "Theol/Rel Voc", "Phys Sci","Nucl/Ind Rad/Bio Techn",
                           "Psych", "Crim Just/Fire Prot", "Publ Aff/Policy/Soc Wo", "Soc Sci", "Constr Serv", "Electr/Mech Rep/Techn",
                           "Transp", "Fine Arts", "Med/Hlth Sci Serv", "Bus", "Hist")
data$degfield <- relevel(data$degfield, "Educ Admin/Teach")
data$marst <- relevel(data$marst, "Never married/single")  # Single as baseline for marst

#########################################################################
################### Saving the Data #####################################
#########################################################################

data <- data[,c("sex", "marst", "race", "speakeng", "hispanic", "schltype", "degfield", "vetstat", "yos", "educd", "education","exp", "exp2", "age", "ind1990c",  "occ2010c",
                 "region", "famsize", "nchlt5","dchlt5", "dchlt19", "msa", "metro", "hw", "hoursworked", "incwage", "wwage", "lwwage")]

#########################################################################
#### Finalize Data Preparation for specific Analysis (04/2018) ##########
#########################################################################

## Save separate data set with observations holding a Bachelor degree 
data <- subset(data, degfield!="Bachelor")
data$degfield <- droplevels(data1$degfield)
save(data, file="ACS2016Bachelor.rda")
