### File to prepare data for tutorial, starting from raw ACS data excerpt
rm(list=ls())
library(checkmate)

# Enter the directory where all files are saved here:
path = "yourdirectory"

setwd(paste0(path))

# Run file with help functions
source(paste0(path, "/helpers_siminf.R"))

# Load cleaned data ("ACS2016Bachelor.rda")
load(paste0(path, "/ACS2016Bachelor.rda"))

# Basic sample composition as in Gender Gap Paper
# Here: Further sample restrictions 

#########################################################################################
############## Focus on a (simplified) subsample of men and women #######################
#########################################################################################

# Only college graduates (Bachelor data used)

# Rename female dummy
data$fem = data$sex

# Singles 
data$nevermarried = as.numeric(data$marst == "Never married/single")
data$married = as.numeric(data$marst == "Married, spouse present" | data$marst == "Married, spouse absent")
data = data[data$nevermarried == 1 | data$married == 1,]  

# Rename Child Dummy
data$chld19 = data$dchlt19

# Only age 25 to 40
data = data[data$age >= 25 & data$age <=40,] 

# White, non-hispanic
data = data[data$race == "White",]
data = data[data$hispanic == FALSE,]

# Non-Veteran
data = data[data$vetstat == "Not a veteran",]

# Only civilian population
data = data[data$ind1990c != "MILIT",]
data = data[data$occ2010c != "Milit Specific",]

# Speanking english only or speaking englisch very well
data = data[data$speakeng == "Yes, speaks very well" | data$speakeng == "Yes, speaks only English",]


#### Clean from categories with low variability

# Factor variables first
tol = 10e-3
data$occ = checkvar_factor(data$occ2010c, tol = tol)
data$deg = checkvar_factor(data$degfield, tol = tol)
data$ind = checkvar_factor(data$ind1990c, tol = tol)
data$region = checkvar_factor(data$region, tol = tol)


###############################
##### Drop Levels  ############
###############################

data$occ = droplevels(data$occ)
data$deg = droplevels(data$deg)
data$ind = droplevels(data$ind)
data$speakeng = droplevels(data$speakeng)
data$region = droplevels(data$region)

###############################
###### Drop NAs ###############
###############################
data = data[complete.cases(data),]
  
  
data = data[,c("incwage", "lwwage", "fem", "married", "nevermarried", "chld19", "region", "msa", "deg", "occ", "ind", "hw", "yos", "exp", "exp2", "age")]

############################################
############## SAVE DATA ###################
############################################

# As Rdata
save(data, file = "ACS2016_gender.rda")


