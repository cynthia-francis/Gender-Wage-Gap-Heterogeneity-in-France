
DGP_desc5 = function(n, p, betamax = 4, decay = 0.99, threshold = 0, noisevar = 10,  ...){
  
  beta = vector("numeric", length = p)
  
  for (j in 1:p){
    beta[j]= betamax*(j)^{-decay}
  }
  
  beta[beta<threshold] = 0
  
  covar=toeplitz(0.9^(0:(p-1)))
  diag(covar) = rep(1,p)
  mu = rep(0,p)
  
  x=rmvnorm(n=n, mean=mu, sigma=covar)
  e = rnorm(n, sd = sqrt(noisevar))
  y = x%*%beta + e
  
  colnames(x) = paste0("Var", seq( from = 1, to = p ))
  names(y) = "y"
  return(list(data = data.frame(y,x), beta = beta, covar = covar))
}

