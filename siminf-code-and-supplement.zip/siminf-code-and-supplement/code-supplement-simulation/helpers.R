# File with helper functions for merging simulation results

# Number of correct rejections (power)


correj <- function(x,y, alpha){
  res <- numeric(length(nrow(x)))
  stopifnot(class(x) == "matrix")
  stopifnot(class(y) == "matrix")
  
  for(j in 1:nrow(x)){
    res[j] <- sum(x[j,y[j,]!=0] <= alpha)
  }
  res
}


# Number of incorrect rejections (power)

incorrej <- function(x,y, alpha){
  res <- numeric(length(nrow(x)))
  stopifnot(class(x) == "matrix")
  stopifnot(class(y) == "matrix")
  
  for(j in 1:nrow(x)){
    res[j] <- sum(x[j,y[j,]==0] <= alpha)
  }
  res
}

#### FWER

onefalserej <- function(x,y, alpha){
  res <- numeric(length(nrow(x)))
  stopifnot(class(x) == "matrix")
  stopifnot(class(y) == "matrix")
  
  for(j in 1:nrow(x)){
    res[j] <- sum(x[j,y[j,]==0] <= alpha)>0
  }
  res
}