rm(list=ls())
library(hdm)  # correction methods available from Version 0.3.0 on

library(mvtnorm)
wspace = "/work/fwnv625/simulation"

setwd(wspace)

source(paste0(wspace, "/DGP_s6.R"))

R = 5000

R1 = 625
ind = seq(1,R+1-R1, R1)




 i = 8   


j1 = ind[i]

j1

j1+R1-1

n = 200
p = 60

pvals1 <- pvals2 <- pvals3 <- pvals4 <- pvals5 <-  pvals6 <- matrix(NA, nrow = R, ncol = p)
pvalsols1 <- pvalsols2 <- pvalsols3 <- pvalsols4 <- pvalsols5 <- matrix(NA, nrow = R, ncol = p)
betas <- matrix(NA, ncol = p, nrow = R)

rejconf <- correjconf <- incorrejconf <- vector(mode = "integer", length = R)
CI <- array(NA, dim = c(p,2,R))

begin = Sys.time()
begin
set.seed(14141)
for (j in j1:(j1+R1-1)){
  
  set.seed(1234567 + as.numeric(j))
  print(j)
  DGP1 <- DGP_desc5(n,p, betamax = 9, decay = 0.99, threshold = 0.75, noisevar = 3)
  y <- DGP1$data$y
  x <- as.matrix(DGP1$data[,-1,drop=F])
  betas[j,] <- beta <- DGP1$beta
  
  
  rl = rlassoEffects(x,y, index = c(1:p), penalty = list(homoscedastic = TRUE,   X.dependent.lambda = TRUE), method = "double selection")
  ols = lm(y ~-1 + x)
  
  set.seed(123 + as.numeric(j))
  pvals1[j,] <- p_adjust(rl, method = "RW", stepdown = TRUE)[,2]
  
  
  
  
  pvals3[j,] <- p_adjust(rl, method = "BH")[,2]
  pvals4[j,] <- p_adjust(rl, method = "bonferroni")[,2]
  pvals5[j,] <- p_adjust(rl, method = "holm")[,2]
  pvals6[j,] <- p_adjust(rl, method = "none")[,2]
  
  
  
  
  
  
  
  
  
  
  
  
  
}
end = Sys.time()
time = end - begin
time

ps <- list(pvals1, pvals2, pvals3, pvals4, pvals5, pvals6)
names(ps) <- c("RW sd", "RW", "BH",  "bonf", "holm", "none")




# with toeplitz cov
save.image(paste0("simulation_server_",p,"_", n, "_R_",R, "_file_", i, ".RData"))

