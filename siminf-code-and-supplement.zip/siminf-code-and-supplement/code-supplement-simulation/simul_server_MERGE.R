
## Merge results from simulations run on server
rm(list=ls())

# Change to your directory
dir <- "yourdirectory"
setwd(dir)

# Helper functions for calculation of results (FWER, Number of false Rej etc.)
source("helpers.R")

# Merge Results, set up objects for betas and pvalues (from first file)

load(paste0(dir, "/results/simulation_server_60_200_R_5000_file_1.RData"))
betasMERGE = betas
psMERGE = ps

# Plug results from all runs into the merge objects

for (i in 2:8){
  load(paste0(dir, "/results/simulation_server_60_200_R_5000_file_", i, ".RData"))
  
  betasMERGE[j1:(j1+R1-1),] = betas[j1:(j1+R1-1),]
  
  for (l in 1:length(psMERGE)){
  psMERGE[[l]][j1:(j1+R1-1),] = ps[[l]][j1:(j1+R1-1),]
  }
  
}


alphas = c(0.01, 0.05, 0.1)

for (m in 1:length(alphas)){
  alpha = alphas[m]


  rej <- lapply(psMERGE, function(x) apply(x, 1, function(x) sum(x <= alpha)))
  
  
  # Average Rej
  avgrejrl = lapply(rej, mean)
  
  avgrejrl
  
  sdrejrl = lapply(rej, sd)
  sdrejrl
  
  mean(rejconf)
  
  correjrl <- lapply(psMERGE, function(x) correj(x, betasMERGE, alpha))
  
  # Average Rej
  avgcorrejrl = lapply(correjrl, mean)
  avgcorrejrl
  
  sdcorrejrl = lapply(correjrl, sd)
  sdcorrejrl
  
  # Incorrect Rej
  incorrejrl <- lapply(psMERGE, function(x) incorrej(x, betasMERGE, alpha))
  
  
  # Average Rej
  avgincorrejrl = lapply(incorrejrl, function(x) sum(x)/R)
  avgincorrejrl
  
  sdincorrejrl = lapply(incorrejrl, sd)
  sdincorrejrl
  
  #### FWER
  
  onefalserejrl = lapply(psMERGE, function(x) onefalserej(x, betasMERGE, alpha))
  
  
  sizerl = lapply(onefalserejrl, function(x) sum(x)/R)
  sizerl
 
  
  #### FDR = no. false rej / no. rej
  
  falsedisc = mapply("/", incorrejrl, rej, SIMPLIFY = FALSE)
  
  FDR = lapply(falsedisc, function(x) sum(x)/R)
  FDR
 
  ##### Save Results
  
  save(avgrejrl, file = paste0("avgrejrl_alpha", alpha*100, ".RData"))
  save(sdrejrl, file =  paste0("sdrejrl_alpha", alpha*100, ".RData"))
  
  save(avgcorrejrl, file =  paste0("avgcorrejrl_alpha", alpha*100, ".RData"))
  save(sdcorrejrl, file =  paste0("sdcorrejrl_alpha", alpha*100, ".RData"))

  save(avgincorrejrl,  file = paste0("avgincorrejrl_alpha", alpha*100, ".RData"))
  save(sdincorrejrl,  file = paste0("sdincorrejrl_alpha", alpha*100, ".RData"))
  
  save(sizerl,  file = paste0("sizerl_alpha", alpha*100, ".RData"))

  save(FDR,  file = paste0("FDR_alpha", alpha*100, ".RData"))
   
  save.image(paste0("simulation_server_MERGE_p",p,"_n", n, "_R_",R, "_alpha", alpha*100, ".RData"))

}


