
## Merge results from simulations run on server
rm(list=ls())

# Change to your directory
dir <- "yourdirectory"
setwd(dir)

# Helper functions for calculation of results (FWER, Number of false Rej etc.)
source("helpers.R")

# Merge Results, set up objects for betas and pvalues (from first file)

load(paste0(dir, "/results/simulation_server_60_500_R_5000_file_1.RData"))
betasMERGE = betas
psMERGE = ps

# Plug results from all runs into the merge objects

for (i in 2:8){
  load(paste0(dir, "/results/simulation_server_60_500_R_5000_file_", i, ".RData"))
  
  betasMERGE[j1:(j1+R1-1),] = betas[j1:(j1+R1-1),]
  
  for (l in 1:length(psMERGE)){
  psMERGE[[l]][j1:(j1+R1-1),] = ps[[l]][j1:(j1+R1-1),]
  }
  
}


alphas = c(0.01, 0.05, 0.1)

for (m in 1:length(alphas)){
  alpha = alphas[m]

  rejn500 <- lapply(psMERGE, function(x) apply(x, 1, function(x) sum(x <= alpha)))
  
  # Average Rej
  avgrejrln500 = lapply(rejn500, mean)
  
  avgrejrln500
  
  sdrejrln500 = lapply(rejn500, sd)
  sdrejrln500
  
  mean(rejconf)
  
  # Number of correct rejections (power)
  
  correjrln500 <- lapply(psMERGE, function(x) correj(x, betasMERGE, alpha))
  
   # Average Rej
  avgcorrejrln500 = lapply(correjrln500, mean)
  avgcorrejrln500
  
  sdcorrejrln500 = lapply(correjrln500, sd)
  sdcorrejrln500
  
  # Number of incorrect rejections (power)
  
  incorrejrln500 <- lapply(psMERGE, function(x) incorrej(x, betasMERGE, alpha))
  
  # Average Rej
  avgincorrejrln500 = lapply(incorrejrln500, function(x) sum(x)/R)
  avgincorrejrln500
  
  sdincorrejrln500 = lapply(incorrejrln500, sd)
  sdincorrejrln500
  
  #### FWER
  
  onefalserejrln500 = lapply(psMERGE, function(x) onefalserej(x, betasMERGE, alpha))
  
  
  sizerln500 = lapply(onefalserejrln500, function(x) sum(x)/R)
  sizerln500
  

#### FDR = no. false rej / no. rej

  falsediscn500 = mapply("/", incorrejrln500, rejn500, SIMPLIFY = FALSE)
  
  FDRn500 = lapply(falsediscn500, function(x) sum(x)/R)
  FDRn500


##### Save Results

save(avgrejrln500, file = paste0("avgrejrl_n500_alpha", alpha*100, ".RData"))
save(sdrejrln500, file =  paste0("sdrejrl_n500_alpha", alpha*100, ".RData"))

save(avgcorrejrln500, file =  paste0("avgcorrejrl_n500_alpha", alpha*100, ".RData"))
save(sdcorrejrln500, file =  paste0("sdcorrejrl_n500_alpha", alpha*100, ".RData"))

save(avgincorrejrln500,  file = paste0("avgincorrejrl_n500_alpha", alpha*100, ".RData"))
save(sdincorrejrln500,  file = paste0("sdincorrejrl_n500_alpha", alpha*100, ".RData"))

save(sizerln500,  file = paste0("sizerl_n500_alpha", alpha*100, ".RData"))

save(FDRn500,  file = paste0("FDR_n500_alpha", alpha*100, ".RData"))

save.image(paste0("simulation_server_MERGE_p",p,"_n", n, "_R_",R, "_alpha", alpha*100, ".RData"))

}


